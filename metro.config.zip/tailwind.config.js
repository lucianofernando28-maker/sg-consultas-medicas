// tailwind.config.js
module.exports = {
  content: ["./app/**/*.{js,jsx,ts,tsx}", "./components/**/*.{js,jsx,ts,tsx}"], // ajuste para a pasta onde está o seu código (ex: src/)
  theme: {
    extend: {},
  },
  plugins: [],
};
