module.exports = function (api) {
  api.cache(true);
  return {
    presets: [["babel-preset-expo", { jsxImportSource: "nativewind" }]],
    plugins: [
      // 1. Plugin do NativeWind v4 (deve ir em plugins, NÃO em presets)
      "nativewind/babel",

      // 2. O seu plugin de aliases existente
      [
        "module-resolver",
        {
          root: ["."],
          alias: {
            "@": "./",
            "@components": "./src/components",
            "@app": "./src/app",
          },
          extensions: [".ios.js", ".android.js", ".js", ".ts", ".tsx", ".json"],
        },
      ],
    ],
  };
};
