import { Ionicons } from "@expo/vector-icons";
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";

/*
const links = [
  { id: 1, title: "Início", url: "/index" as const },
  { id: 2, title: "Pacientes", url: "/patient" as const },
  { id: 3, title: "Consultas", url: "/consult" as const },
  { id: 4, title: "Perfil", url: "" as const },
];*/

export default function Index() {
  return (
    <SafeAreaView
      className="flex-1 bg-gray-50"
      edges={["top", "left", "right"]}
    >
      <ScrollView
        className="flex-1 px-5 pt-2"
        showsVerticalScrollIndicator={false}
      >
        {/* Header - Saudação e Perfil */}
        <View className="flex-row justify-between items-center mb-2">
          <Text className="text-3xl font-bold text-gray-900">Olá, Ana!</Text>
          <TouchableOpacity
            className="w-10 h-10 rounded-full bg-gray-100 items-center 
justify-center border border-gray-200"
          >
            <Ionicons name="person" size={22} color="#4B5563" />
          </TouchableOpacity>
        </View>
        <Text className="text-gray-500 text-base mb-6">
          Aqui está o resumo das suas consultas.
        </Text>

        {/* Cards de Resumo */}
        <View className="flex-row justify-between mb-6">
          {/* Card Consultas Futuras */}
          <View className="w-[48%] bg-blue-50/60 p-4 rounded-2xl border border-blue-100">
            <View className="w-10 h-10 rounded-xl bg-blue-100 items-center justify-center mb-3">
              <Ionicons name="calendar" size={20} color="#2563EB" />
            </View>
            <Text className="text-2xl font-bold text-gray-900 mb-1">3</Text>
            <Text className="text-gray-500 font-medium text-sm">
              Consultas futuras
            </Text>
          </View>

          {/* Card Consultas Anteriores */}
          <View
            className="w-[48%] bg-emerald-50/60 p-4 rounded-2xl border 
border-emerald-100"
          >
            <View
              className="w-10 h-10 rounded-xl bg-emerald-100 items-center justify-center 
mb-3"
            >
              <Ionicons
                name="checkmark-done-circle"
                size={20}
                color="#059669"
              />
            </View>
            <Text className="text-2xl font-bold text-gray-900 mb-1">5</Text>
            <Text className="text-gray-500 font-medium text-sm">
              Consultas anteriores
            </Text>
          </View>
        </View>

        {/* Botão Marcar Nova Consulta */}
        <TouchableOpacity
          className="bg-blue-600 flex-row justify-center items-center py-4 
rounded-2xl mb-8 shadow-sm active:bg-blue-700"
        >
          <Ionicons name="add" size={20} color="#FFFFFF" />
          <Text className="text-white font-semibold text-base ml-2">
            Marcar nova consulta
          </Text>
        </TouchableOpacity>

        {/* Seção Próximas Consultas */}
        <View className="flex-row justify-between items-center mb-4">
          <Text className="text-xl font-bold text-gray-900">
            Próximas consultas
          </Text>
          <TouchableOpacity className="flex-row items-center">
            <Text className="text-blue-600 font-medium mr-1">Ver todas</Text>
            <Ionicons name="chevron-forward" size={16} color="#2563EB" />
          </TouchableOpacity>
        </View>

        {/* Card Médico 1 */}
        <TouchableOpacity
          className="bg-white p-4 rounded-2xl border border-gray-100 flex-row 
items-center justify-between mb-3 shadow-xs"
        >
          <View className="flex-row items-center flex-1">
            <View
              className="w-12 h-12 rounded-full bg-emerald-100 items-center justify-center 
mr-3"
            >
              <Ionicons name="medkit-outline" size={24} color="#059669" />
            </View>
            <View className="flex-1">
              <Text className="text-base font-bold text-gray-900">
                Dr. Carlos Silva
              </Text>
              <Text className="text-gray-400 text-sm mb-1">Medicina Geral</Text>
              <Text className="text-gray-500 text-xs font-medium">
                12 Abr 2025 • 10:30
              </Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
        </TouchableOpacity>

        {/* Card Médico 2 */}
        <TouchableOpacity
          className="bg-white p-4 rounded-2xl border border-gray-100 flex-row 
items-center justify-between mb-8 shadow-xs"
        >
          <View className="flex-row items-center flex-1">
            <View
              className="w-12 h-12 rounded-full bg-rose-100 items-center justify-center 
mr-3"
            >
              <Ionicons name="heart-outline" size={24} color="#E11D48" />
            </View>
            <View className="flex-1">
              <Text className="text-base font-bold text-gray-900">
                Dra. Mariana Costa
              </Text>
              <Text className="text-gray-400 text-sm mb-1">Cardiologia</Text>
              <Text className="text-gray-500 text-xs font-medium">
                28 Abr 2025 • 14:00
              </Text>
            </View>
          </View>
          <Ionicons name="chevron-forward" size={20} color="#9CA3AF" />
        </TouchableOpacity>
      </ScrollView>

      {/* Barra de Navegação Inferior (Bottom Tab) */}
      <View
        className="flex-row justify-around items-center bg-white py-3 border-t 
border-gray-100 px-4"
      >
        <TouchableOpacity className="items-center">
          <Ionicons name="home" size={22} color="#2563EB" />
          <Text className="text-xs font-semibold text-blue-600 mt-1">
            Início
          </Text>
        </TouchableOpacity>

        <TouchableOpacity className="items-center">
          <Ionicons name="person" size={22} color="#9CA3AF" />
          <Text className="text-xs font-medium text-gray-400 mt-1">
            Pacientes
          </Text>
        </TouchableOpacity>

        <TouchableOpacity className="items-center">
          <Ionicons name="calendar" size={22} color="#9CA3AF" />
          <Text className="text-xs font-medium text-gray-400 mt-1">
            Consultas
          </Text>
        </TouchableOpacity>

        <TouchableOpacity className="items-center">
          <Ionicons name="person" size={22} color="#9CA3AF" />
          <Text className="text-xs font-medium text-gray-400 mt-1">Perfil</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },

  link: {
    color: "red",
    fontWeight: "bold",
  },
});
